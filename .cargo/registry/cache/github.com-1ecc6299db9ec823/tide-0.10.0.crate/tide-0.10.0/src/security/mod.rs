//! HTTP Security Headers.

mod cors;

pub use cors::{CorsMiddleware, Origin};
