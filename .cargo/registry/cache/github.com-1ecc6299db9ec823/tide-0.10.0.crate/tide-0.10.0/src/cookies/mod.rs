//! HTTP cookies.

mod middleware;

pub(crate) use middleware::{CookieData, CookiesMiddleware};
