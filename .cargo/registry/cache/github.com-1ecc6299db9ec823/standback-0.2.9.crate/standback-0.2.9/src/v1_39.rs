// Unfortunately, all stabilized APIs in 1.39.0 cannot be implemented by a
// third-party crate.
