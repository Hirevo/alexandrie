`librustc_target` contains some very low-level details that are
specific to different compilation targets and so forth.

For more information about how rustc works, see the [rustc dev guide].

[rustc dev guide]: https://rustc-dev-guide.rust-lang.org/
