Below is a list of sponsors for the clap-rs project

If you are interested in becoming a sponsor for this project please our [sponsorship page](https://clap.rs/sponsorship/).

## Recurring Sponsors:

| [<img alt="Noelia Seva-Gonzalez" src="https://clap.rs/wp-content/uploads/2017/10/noelia_sm-1.png" width="117">](https://noeliasg.com/about/)  | [<img alt="messense" src="https://clap.rs/wp-content/uploads/2018/01/messense-400x400.png" width="117">](https://github.com/messense)  | [<img alt="Josh" src="https://clap.rs/wp-content/uploads/2018/11/josh_t.jpg" width="117">](https://joshtriplett.org)  | <img alt="Stephen Oats" src="https://clap.rs/wp-content/uploads/2019/03/stephenoats.png" width="117"> |
|:-:|:-:|:-:|:-:|
|Noelia Seva-Gonzalez | Messense | Josh Triplett | Stephen Oats |


## Single-Donation and Former Sponsors:

| [<img alt="Rob Tsuk" src="https://clap.rs/wp-content/uploads/2017/10/robtsuk_sm.png" width="117">](https://github.com/rtsuk)| | |
|:-:|:-:|:-:|
|Rob Tsuk| | |

