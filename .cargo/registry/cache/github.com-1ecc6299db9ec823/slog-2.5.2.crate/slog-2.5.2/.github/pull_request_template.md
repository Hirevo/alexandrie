Make sure to:

* [ ] Add an entry to CHANGELOG.md (if neccessary)
