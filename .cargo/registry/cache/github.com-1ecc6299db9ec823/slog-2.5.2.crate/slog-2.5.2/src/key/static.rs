/// Key type
pub type Key = &'static str;
