# handlebars wasm modules

## cli

A commandline tool to render handlebars with given json input.

