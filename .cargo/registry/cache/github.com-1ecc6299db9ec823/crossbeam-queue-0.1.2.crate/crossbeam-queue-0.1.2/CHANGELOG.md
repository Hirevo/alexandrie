# Version 0.1.2

- Update `crossbeam-utils` to `0.6.5`.

# Version 0.1.1

- Update `crossbeam-utils` to `0.6.4`.

# Version 0.1.0

- Initial version with `ArrayQueue` and `SegQueue`.
