## Summary
Explain what is going on.

## Your Environment
| Software         | Version(s) |
| ---------------- | ---------- |
| kv-log-macro      |
| Rustc            |
| Operating System |
