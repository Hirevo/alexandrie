# piper (deprecated)

**NOTE:** This crate is DEPRECATED.

Use the following crates instead:

- [`async-channel`](https://docs.rs/async-channel)
- [`async-dup`](https://docs.rs/async-dup)
- [`async-lock`](https://docs.rs/async-lock)
- [`async-mutex`](https://docs.rs/async-mutex)
- [`blocking`](https://docs.rs/blocking)
- [`event-listener`](https://docs.rs/event-listener)
