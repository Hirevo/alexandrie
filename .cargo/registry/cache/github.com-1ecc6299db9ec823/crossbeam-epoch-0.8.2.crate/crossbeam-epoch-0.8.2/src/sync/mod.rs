//! Synchronization primitives.

pub mod list;
pub mod queue;
