//! Platform-specific extensions for Windows.

cfg_std! {
    pub mod io;
}

cfg_unstable! {
    pub mod fs;
}
