// use http_types::{Response, StatusCode};

// #[test]
// fn headers_cmp() {
//     let mut res = Response::new(StatusCode::Ok);
//     res.insert_header("content-type", "application/json");
//     assert_eq!(res.header("content-type").unwrap(), "application/json");
// }
