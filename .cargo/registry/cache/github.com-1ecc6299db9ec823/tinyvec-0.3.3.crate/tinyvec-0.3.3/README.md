[![License:Zlib](https://img.shields.io/badge/License-Zlib-brightgreen.svg)](https://opensource.org/licenses/Zlib)
![Minimum Rust Version](https://img.shields.io/badge/Min%20Rust-1.36-green.svg)
[![travis.ci](https://travis-ci.org/Lokathor/tinyvec.svg?branch=master)](https://travis-ci.org/Lokathor/tinyvec)
[![AppVeyor](https://ci.appveyor.com/api/projects/status/wfnu1tyudka6jbk1/branch/master?svg=true)](https://ci.appveyor.com/project/Lokathor/tinyvec/branch/master)
[![crates.io](https://img.shields.io/crates/v/tinyvec.svg)](https://crates.io/crates/tinyvec)
[![docs.rs](https://docs.rs/tinyvec/badge.svg)](https://docs.rs/tinyvec/)

![Unsafe-Zero-Percent](https://img.shields.io/badge/Unsafety-0%25-brightgreen.svg)

# tinyvec

A 100% safe crate of vec-like types.

For details, please see [the docs.rs documentation](https://docs.rs/tinyvec/)
