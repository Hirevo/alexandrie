We use this directory for interactive tests that can't be run in an
automatic fashion. For examples of how to use Rayon, or benchmarks,
see `rayon-demo`.
