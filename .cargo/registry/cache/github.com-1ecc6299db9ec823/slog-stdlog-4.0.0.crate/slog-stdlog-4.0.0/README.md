<p align="center">
  <a href="https://travis-ci.org/slog-rs/stdlog">
      <img src="https://img.shields.io/travis/slog-rs/stdlog/master.svg" alt="Travis CI Build Status">
  </a>

  <a href="https://crates.io/crates/slog-stdlog">
      <img src="https://img.shields.io/crates/d/slog-stdlog.svg" alt="slog-stdlog on crates.io">
  </a>

  <a href="https://gitter.im/slog-rs/slog">
      <img src="https://img.shields.io/gitter/room/slog-rs/slog.svg" alt="slog-rs Gitter Chat">
  </a>
</p>

## slog-stdlog - `log` crate adapter for [slog-rs]

See [slog-stdlog documentation](https://docs.rs/slog-stdlog) for details.

For more information, help, to report issues etc. see [slog-rs][slog-rs].

[slog-rs]: //github.com/slog-rs/slog
